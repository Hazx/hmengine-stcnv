<?php
require __DIR__ . '/generate_unserialize_dict.php';
require __DIR__ . '/generate_unserializehash_corpus.php';
require __DIR__ . '/generate_parser_corpus.php';
require __DIR__ . '/generate_execute_corpus.php';
